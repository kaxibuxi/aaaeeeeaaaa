const Discord = require('discord.js');
const client = new Discord.Client();
const Proton = require("proton-io")
require('./util/eventLoader')(client);
const moment = require('moment');
const ytdl=require('ytdl-core')
const servers={

}

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', msg => {
  if (msg.content === '.avatar') {
    msg.channel.send({embed: {
      color: 0x0,
      image: {
        url: msg.author.displayAvatarURL()
    }}});
  };

});
client.on('message', msg => {
  if (msg.content.toLowerCase() === 'sea') {
    msg.channel.send('ase')
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === 'sa') {
    msg.channel.send('as')
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.id') {
    msg.channel.send(msg.author.id)
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.nick') {
    msg.channel.send(msg.author.username)
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.username') {
    msg.channel.send(msg.author.username)
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.kullanıcıadı') {
    msg.channel.send(msg.author.username)
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.corona') {
    msg.channel.send('https://cdn.discordapp.com/attachments/790551351641767987/795334394654097438/unknown.png')
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.tag') {
    msg.channel.send(msg.author.tag)
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.deneme') {
    msg.channel.send('<a:muzdansi:794964811074371625>');
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.davet') {
    msg.channel.send('https://discord.com/oauth2/authorize?client_id=791977957010702367&scope=bot&permissions=8')
    msg.channel.send('https://cdn.discordapp.com/attachments/795366444765937745/795375892321927168/download.jpg')
  }
});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.yardım')
    msg.channel.send({embed: {
      color: 0x0,
      title: "Yararlı komutlar:\n**.corona**\n**.id**\n**.ekonomi**\n\n **Eğlence komutları:**\n**.avatar**\n\n **Normal komutlar:**\n**.tag**\n**.kullanıcıadı-.nick-.username**\n**.davet-.invite**",
      timestamp: new Date(),
              icon_url: "https://cdn.discordapp.com/attachments/794958066189074466/795560600515117066/SneaX.png",
              text: "SneaX 1.0.1 Beta"
    }});

});
client.on('message', msg => {
  if (msg.content.toLowerCase() === '.ekonomi')
    msg.channel.send({embed: {
      color: 0x0,
      title: '\n\n> **Döviz:**\n\nDolar 7,44 Türk Lirası\n Euro 9,03 Türk Lirası\n> **Altın Fiyatları:**\n\nÇeyrek Altın 750,40 Türk Lirası\nGram Altın 452,98 Türk Lirası\nAltın (ONS) 1,896,27\nYarım Altın 1,496,30\nCumhuriyet Altını 2,983,50'
  }});
});

client.login('NzkxOTc3OTU3MDEwNzAyMzY3.X-XA8w.HAQ807imSPjye8kS3rvLIInaG54');
