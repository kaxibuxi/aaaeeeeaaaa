const Moment = require('moment')
const Discord = require('discord.js')
let prefix = 'bot prefix'
module.exports = client => {

  const aktiviteListesi = [
    `bruh | .davet  |.yardım | .corona | .ekonmi | beta 1.0.1`
  ]

  client.user.setStatus('online')

  setInterval(() => {
    const Aktivite = Math.floor(Math.random() * (aktiviteListesi.length - 1))
    client.user.setActivity(aktiviteListesi[Aktivite])
  }, 5000)
}
